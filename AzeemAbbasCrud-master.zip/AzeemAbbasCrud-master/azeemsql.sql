﻿	select * from Locations
	insert into Locations values('Noida', 'this is the best place'),
	('Noida', 'this is the best place'),
	('delhi', 'this is the best place'),
	('meerut', 'this is the best place')

	select * from Customers
	insert into Customers values
	